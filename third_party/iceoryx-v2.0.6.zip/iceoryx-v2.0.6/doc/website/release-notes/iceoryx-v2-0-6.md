# iceoryx v2.0.6

## [v2.0.6](https://github.com/eclipse-iceoryx/iceoryx/tree/v2.0.6) (2024-04-26)

[Full Changelog](https://github.com/eclipse-iceoryx/iceoryx/compare/v2.0.5...v2.0.6)

**Refactoring:**

- Patch cpptoml to use cmake 3.16 [#2011](https://github.com/eclipse-iceoryx/iceoryx/issues/2011)
- Update github actions [#2011](https://github.com/eclipse-iceoryx/iceoryx/issues/2011)
- Remove warning in toml gateway config parser [#2266](https://github.com/eclipse-iceoryx/iceoryx/issues/2266)
- Fix warnings on macOS [#2284](https://github.com/eclipse-iceoryx/iceoryx/issues/2266)
