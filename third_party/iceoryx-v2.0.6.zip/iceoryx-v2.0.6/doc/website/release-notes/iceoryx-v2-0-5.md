# iceoryx v2.0.5

## [v2.0.5](https://github.com/eclipse-iceoryx/iceoryx/tree/v2.0.5) (2023-11-30)

[Full Changelog](https://github.com/eclipse-iceoryx/iceoryx/compare/v2.0.4...v2.0.5)

**Bugfixes:**

- Fix ROS 2 RHEL build [\#2099](https://github.com/eclipse-iceoryx/iceoryx/issues/2099)
