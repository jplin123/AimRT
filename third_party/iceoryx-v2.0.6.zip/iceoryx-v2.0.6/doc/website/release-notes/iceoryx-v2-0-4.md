# iceoryx v2.0.4

## [v2.0.4](https://github.com/eclipse-iceoryx/iceoryx/tree/v2.0.4) (2023-11-27)

[Full Changelog](https://github.com/eclipse-iceoryx/iceoryx/compare/v2.0.3...v2.0.4)

**Features:**

- Add the introspection to the ROS release [\#2099](https://github.com/eclipse-iceoryx/iceoryx/issues/2099)
