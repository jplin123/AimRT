---
title: Waiting for events like arrival of data using C++
---
{! ../iceoryx/iceoryx_examples/waitset/README.md !}
