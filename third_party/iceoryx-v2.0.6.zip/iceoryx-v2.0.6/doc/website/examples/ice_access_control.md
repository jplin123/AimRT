---
title: Configuring access rights for shared memory segments
---

{! ../iceoryx/iceoryx_examples/ice_access_control/README.md !}
