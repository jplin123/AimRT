---
title: Sending data to another process
---

{! ../iceoryx/iceoryx_examples/icehello/README.md !}
