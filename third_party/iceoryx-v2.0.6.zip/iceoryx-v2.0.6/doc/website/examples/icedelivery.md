---
title: Sending and receiving data using C++
---

{! ../iceoryx/iceoryx_examples/icedelivery/README.md !}
