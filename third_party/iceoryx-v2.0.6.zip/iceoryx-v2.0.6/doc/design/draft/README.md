# Draft Design Documents

Here you can find documents related to features which are currently in the 
proof-of-concept or planning phase.
