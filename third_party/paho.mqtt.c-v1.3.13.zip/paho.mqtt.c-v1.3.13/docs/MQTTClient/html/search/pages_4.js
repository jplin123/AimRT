var searchData=
[
  ['subscription_20wildcards_612',['Subscription wildcards',['../wildcard.html',1,'']]],
  ['synchronous_20publication_20example_613',['Synchronous publication example',['../pubsync.html',1,'']]]
];
