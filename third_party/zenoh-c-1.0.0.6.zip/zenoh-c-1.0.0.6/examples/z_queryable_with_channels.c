//
// Copyright (c) 2022 ZettaScale Technology
//
// This program and the accompanying materials are made available under the
// terms of the Eclipse Public License 2.0 which is available at
// http://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
// which is available at https://www.apache.org/licenses/LICENSE-2.0.
//
// SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
//
// Contributors:
//   ZettaScale Zenoh Team, <zenoh@zettascale.tech>

#include <stdio.h>
#include <string.h>
#include <zenoh_macros.h>

#include "zenoh.h"

const char *keyexpr = "demo/example/zenoh-c-queryable";
const char *value = "Queryable from C!";
z_view_keyexpr_t ke;

int main(int argc, char **argv) {
    if (argc > 1) {
        keyexpr = argv[1];
    }
    z_owned_config_t config;
    z_config_default(&config);
    if (argc > 2) {
        if (zc_config_insert_json(z_loan_mut(config), Z_CONFIG_CONNECT_KEY, argv[2]) < 0) {
            printf(
                "Couldn't insert value `%s` in configuration at `%s`. This is likely because `%s` expects a "
                "JSON-serialized list of strings\n",
                argv[2], Z_CONFIG_CONNECT_KEY, Z_CONFIG_CONNECT_KEY);
            exit(-1);
        }
    }

    printf("Opening session...\n");
    z_owned_session_t s;
    if (z_open(&s, z_move(config)) < 0) {
        printf("Unable to open session!\n");
        exit(-1);
    }

    if (z_view_keyexpr_from_str(&ke, keyexpr) < 0) {
        printf("%s is not a valid key expression", keyexpr);
        exit(-1);
    }

    printf("Declaring Queryable on '%s'...\n", keyexpr);
    z_owned_fifo_handler_query_t handler;
    z_owned_closure_query_t closure;
    z_fifo_channel_query_new(&closure, &handler, 16);
    z_owned_queryable_t qable;

    if (z_declare_queryable(&qable, z_loan(s), z_loan(ke), z_move(closure), NULL) < 0) {
        printf("Unable to create queryable.\n");
        exit(-1);
    }

    printf("^C to quit...\n");
    z_owned_query_t oquery;
    for (z_result_t res = z_recv(z_loan(handler), &oquery); res == Z_OK; res = z_recv(z_loan(handler), &oquery)) {
        const z_loaned_query_t *query = z_loan(oquery);
        z_view_string_t key_string;
        z_keyexpr_as_view_string(z_query_keyexpr(query), &key_string);

        z_view_string_t params;
        z_query_parameters(query, &params);

        const z_loaned_bytes_t *payload = z_query_payload(query);
        if (payload != NULL && z_bytes_len(payload) > 0) {
            z_owned_string_t payload_string;
            z_bytes_deserialize_into_string(payload, &payload_string);

            printf(">> [Queryable ] Received Query '%.*s?%.*s' with value '%.*s'\n",
                   (int)z_string_len(z_loan(key_string)), z_string_data(z_loan(key_string)),
                   (int)z_string_len(z_loan(params)), z_string_data(z_loan(params)),
                   (int)z_string_len(z_loan(payload_string)), z_string_data(z_loan(payload_string)));
            z_drop(z_move(payload_string));
        } else {
            printf(">> [Queryable ] Received Query '%.*s?%.*s'\n", (int)z_string_len(z_loan(key_string)),
                   z_string_data(z_loan(key_string)), (int)z_string_len(z_loan(params)), z_string_data(z_loan(params)));
        }
        z_query_reply_options_t options;
        z_query_reply_options_default(&options);

        z_owned_bytes_t reply_payload;
        z_bytes_from_static_str(&reply_payload, value);
        z_query_reply(query, z_loan(ke), z_move(reply_payload), &options);
        z_drop(z_move(oquery));
    }

    z_undeclare_queryable(z_move(qable));
    z_drop(z_move(handler));
    z_close(z_move(s));
    return 0;
}
