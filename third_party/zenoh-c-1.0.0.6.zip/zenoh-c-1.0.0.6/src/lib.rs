//
// Copyright (c) 2017, 2022 ZettaScale Technology.
//
// This program and the accompanying materials are made available under the
// terms of the Eclipse Public License 2.0 which is available at
// http://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
// which is available at https://www.apache.org/licenses/LICENSE-2.0.
//
// SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
//
// Contributors:
//   ZettaScale Zenoh team, <zenoh@zettascale.tech>
//

#![allow(non_camel_case_types)]

use std::{cmp::min, slice};

use libc::c_void;

#[macro_use]
mod transmute;
pub mod opaque_types;
pub use crate::opaque_types::*;

mod collections;
pub mod result;
pub use crate::collections::*;
mod config;
pub use crate::config::*;
pub mod encoding;
pub use crate::encoding::*;
mod commons;
pub use crate::commons::*;
mod payload;
pub use crate::payload::*;
mod keyexpr;
pub use crate::keyexpr::*;
#[cfg(feature = "unstable")]
mod info;
#[cfg(feature = "unstable")]
pub use crate::info::*;
mod get;
pub use crate::get::*;
mod queryable;
pub use crate::queryable::*;
mod put;
pub use crate::put::*;
mod scouting;
pub use crate::scouting::*;
mod session;
pub use crate::session::*;
mod subscriber;
pub use crate::subscriber::*;
mod publisher;
pub use crate::publisher::*;
mod closures;
pub use closures::*;
pub mod platform;
pub use platform::*;
#[cfg(feature = "unstable")]
mod liveliness;
#[cfg(feature = "unstable")]
pub use liveliness::*;
#[cfg(feature = "unstable")]
mod publication_cache;
#[cfg(feature = "unstable")]
pub use publication_cache::*;
#[cfg(feature = "unstable")]
mod querying_subscriber;
#[cfg(feature = "unstable")]
pub use querying_subscriber::*;
#[cfg(all(feature = "shared-memory", feature = "unstable"))]
pub mod context;

#[cfg(all(feature = "shared-memory", feature = "unstable"))]
pub mod shm;

/// Initialises the zenoh runtime logger.
///
/// Note that unless you built zenoh-c with the `logger-autoinit` feature disabled,
/// this will be performed automatically by `z_open` and `z_scout`.
#[no_mangle]
pub extern "C" fn zc_init_logger() {
    zenoh::try_init_log_from_env();
}

// Test should be runned with `cargo test --no-default-features`
#[test]
#[cfg(not(feature = "default"))]
fn test_no_default_features() {
    assert_eq!(
        zenoh::FEATURES,
        concat!(
            // " zenoh/auth_pubkey",
            // " zenoh/auth_usrpwd",
            // " zenoh/complete_n",
            //" zenoh/shared-memory",
            // " zenoh/stats",
            // " zenoh/transport_multilink",
            // " zenoh/transport_quic",
            // " zenoh/transport_serial",
            // " zenoh/transport_unixpipe",
            // " zenoh/transport_tcp",
            // " zenoh/transport_tls",
            // " zenoh/transport_udp",
            // " zenoh/transport_unixsock-stream",
            // " zenoh/transport_ws",
            // " zenoh/unstable",
            // " zenoh/default",
        )
    );
}

trait CopyableToCArray {
    fn copy_to_c_array(&self, buf: *mut c_void, len: usize) -> usize;
}

impl CopyableToCArray for &[u8] {
    fn copy_to_c_array(&self, buf: *mut c_void, len: usize) -> usize {
        if buf.is_null() || (len == 0 && !self.is_empty()) {
            return 0;
        }

        let max_len = min(len, self.len());
        let b = unsafe { slice::from_raw_parts_mut(buf as *mut u8, max_len) };
        b[0..max_len].copy_from_slice(&self[0..max_len]);
        max_len
    }
}

impl CopyableToCArray for &str {
    fn copy_to_c_array(&self, buf: *mut c_void, len: usize) -> usize {
        self.as_bytes().copy_to_c_array(buf, len)
    }
}
