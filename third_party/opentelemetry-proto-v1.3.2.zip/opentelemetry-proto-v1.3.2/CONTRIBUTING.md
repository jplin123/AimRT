# Contributing

Read OpenTelemetry project [contributing
guide](https://github.com/open-telemetry/community/blob/main/CONTRIBUTING.md)
for general information about the project.

## Prerequisites

- `Docker`

## Making changes to the .proto files

After making any changes to .proto files make sure to generate all
implementation by running `make gen-all`.
